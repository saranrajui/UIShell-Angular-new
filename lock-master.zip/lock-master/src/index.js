import Lock from './lock';
import Passwordless from './passwordless';

export const Auth0LockPasswordless = Passwordless;
export const Auth0Lock = Lock;
export default Lock;
