import React from 'react';

const PaneSeparator = () => <div className="auth0-lock-pane-separator" />;

export default PaneSeparator;
