// This file was automatically translated.
// Feel free to submit a PR if you find a more accurate translation.

export default {
  error: {
    forgotPassword: {
      too_many_requests:
        'Bạn đã sử dụng tối đa số lần đổi mật khẩu được cho phép. Vui lòng thử lại sau.',
      'lock.fallback': 'Đã có lỗi xảy ra trong lúc thay đổi mật khẩu, chúng tôi rất lấy làm tiếc.',
      enterprise_email:
        'Tên miền email của bạn là một phần của một nhà cung cấp nhận dạng doanh nghiệp. Để đặt lại mật khẩu của bạn, vui lòng xem quản trị viên bảo mật của bạn.'
    },
    login: {
      blocked_user: 'Tài khoản đã bị khóa.',
      invalid_user_password: 'Tài khoản không tồn tại.',
      'lock.fallback': 'Đã có lỗi xảy ra trong lúc đăng nhập, chung tôi rất lấy làm tiếc.',
      'lock.invalid_code': 'Sai mã số',
      'lock.invalid_email_password': 'Email / mật khẩu không chính xác.',
      'lock.invalid_username_password': 'Tài khoản / mật khẩu không chính xác.',
      'lock.network': 'Không thể kết nói đến server. Vui lòng kiểm lại đường truyền và thử lại.',
      'lock.popup_closed': 'Cửa sổ Popup đã đóng. Vui lòng thử lại.',
      'lock.unauthorized': 'Tài khoản không được cấp phép. Vui lòng thử lại.',
      'lock.mfa_registration_required':
        'Xác thực đa yếu tố được yêu cầu nhưng thiết bị của bạn không có đăng ký. Vui lòng đăng ký và thử lại sau.',
      'lock.mfa_invalid_code': 'Sai mã số. Vui lòng thử lại.',
      password_change_required:
        'Bạn cần phải thay đổi mật khẩu vì đây là lần đầu bạn đăng nhập, hoặc mật khẩu của bạn đã hết hạn.',
      password_leaked:
        'Tài khoản của bạn đã bị khóa do mật khẩu của bạn đã bị rò rỉ ở 1 website khác. Chúng tôi đã gửi cho bạn 1 email hướng dẫn cách mở khóa tài khoản.',
      too_many_attempts: 'Tài khoản của bạn đã bị khóa do liên tục đăng nhập thất bại nhiều lần.',
      session_missing:
        'Không thể hoàn tất yêu cầu xác thực của bạn. Vui lòng thử lại sau khi đóng tất cả các hộp thoại mở',
      'hrd.not_matching_email': 'Xin vui lòng, sử dụng email công ty của bạn để đăng nhập.',
      too_many_requests:
        'Chúng tôi xin lỗi. Có quá nhiều yêu cầu ngay bây giờ. Hãy tải lại trang và thử lại. Nếu điều này vẫn còn, vui lòng thử lại sau.'
    },
    passwordless: {
      'bad.email': 'Email không hợp lệ.',
      'bad.phone_number': 'Số điện thoại không hợp lệ.',
      'lock.fallback': 'Đã có lỗi xãy ra, chúng tôi rất lấy làm tiếc.'
    },
    signUp: {
      invalid_password: 'Mật khẩu không hợp lệ.',
      'lock.fallback': 'Đã có lỗi xảy ra trong lúc đăng ký, chúng tôi rất lấy làm tiếc.',
      password_dictionary_error: 'Mật khẩu quá dễ đoán.',
      password_no_user_info_error: 'Mật khẩu giống thông tin cá nhân.',
      password_strength_error: 'Mật khẩu quá yếu.',
      user_exists: 'Tài khoản đã có người sử dụng.',
      username_exists: 'Tài khoản đã có người sử dụng.'
    }
  },
  success: {
    logIn: 'Đăng nhập thành công.',
    forgotPassword: 'Chúng tôi vừa gửi cho bạn 1 email hướng dẫn cách phục hồi mật khẩu.',
    magicLink: 'Chúng tôi vừa gửi cho bạn 1 đường link đăng nhập<br />tới %s.',
    signUp: 'Đăng ký thành công.'
  },
  blankErrorHint: 'Không được để trống',
  codeInputPlaceholder: 'Mã số của bạn',
  databaseEnterpriseLoginInstructions: '',
  databaseEnterpriseAlternativeLoginInstructions: 'hoặc',
  databaseSignUpInstructions: '',
  databaseAlternativeSignUpInstructions: 'hoặc',
  emailInputPlaceholder: 'email@domain.com',
  enterpriseLoginIntructions: 'Đăng nhập với thông tin đăng nhập công ty của bạn',
  enterpriseActiveLoginInstructions: 'Vui lòng điền thông tin đăng nhập công ty của bạn %s.',
  failedLabel: 'Thất bại!',
  forgotPasswordAction: 'Quên mật khẩu?',
  forgotPasswordInstructions:
    'Vui lòng điền email vào đây. Chúng tôi sẽ gửi thư hướng dẫn phục hồi mật khẩu cho bạn ngay lập tức.',
  forgotPasswordSubmitLabel: 'Gửi email',
  invalidErrorHint: 'Không hợp lệ',
  lastLoginInstructions: 'Lần đăng nhập gần đây nhất của bạn',
  loginAtLabel: 'Đăng nhập vào lúc %s',
  loginLabel: 'Đăng nhập',
  loginSubmitLabel: 'Đăng nhập',
  loginWithLabel: 'Đăng nhập với %s',
  notYourAccountAction: 'Không phải tài khoản của bạn?',
  passwordInputPlaceholder: 'Mật khẩu',
  passwordStrength: {
    containsAtLeast: 'Phải có ít nhất %d các ký tự sau %d:',
    identicalChars: 'Tối đa %d kí tự (e.g., không cho phép"%s")',
    nonEmpty: 'Mật khẩu không được để trống',
    numbers: 'Số (i.e. 0-9)',
    lengthAtLeast: 'Phải có ít nhất %d kí tự',
    lowerCase: 'Chữ không in hoa (a-z)',
    shouldContain: 'Phải có:',
    specialCharacters: 'Kí tự đặc biệt (e.g. !@#$%^&*)',
    upperCase: 'Chữ in hoa (A-Z)'
  },
  passwordlessEmailAlternativeInstructions:
    'Bằng không, nhập email của bạn để đăng nhập<br/>hoặc đăng ký.',
  passwordlessEmailCodeInstructions: '1 email có mã số đã được gửi tới email %s.',
  passwordlessEmailInstructions: 'Nhập email của bạn để đăng nhập<br/>hoặc đăng ký',
  passwordlessSMSAlternativeInstructions:
    'Bằng không, nhập số điện thoại của bạn để đăng nhập<br/>hoặc đăng ký',
  passwordlessSMSCodeInstructions: '1 SMS có mã số đã được gửi <br/>tới %s.',
  passwordlessSMSInstructions: 'Nhập số điện thoại của bạn để đăng nhập<br/>hoặc đăng ký',
  phoneNumberInputPlaceholder: 'Số điện thoại',
  resendCodeAction: 'Không nhận được mã số?',
  resendLabel: 'Gửi lại',
  resendingLabel: 'Đang gửi lại...',
  retryLabel: 'Thử lại',
  sentLabel: 'Đã gửi!',
  signUpLabel: 'Đăng ký',
  signUpSubmitLabel: 'Đăng ký',
  signUpWithLabel: 'Đăng ký với %s',
  socialLoginInstructions: '',
  socialSignUpInstructions: '',
  ssoEnabled: 'Đăng nhập 1 lần đã được kích hoạt',
  submitLabel: 'Gửi',
  unrecoverableError:
    'Có lỗi hệ thống xảy ra.<br />Vui lòng liên hệ bộ phận kỹ thuật để được giúp đỡ.',
  usernameFormatErrorHint:
    'Sử dụng các ký tự %d____%d, các con số và các ký tự sau: "_", ".", "+", "-"',
  usernameInputPlaceholder: 'Tên tài khoản',
  usernameOrEmailInputPlaceholder: 'Tên tài khoản/Email',
  title: 'Auth0',
  welcome: 'Xin chào, %s!',
  windowsAuthInstructions: 'Đã đã được kết nối tự mạng của công ty&hellip;',
  windowsAuthLabel: 'Xác thực Windows',
  mfaInputPlaceholder: 'Mã số',
  mfaLoginTitle: 'Xác thực 2 nhân tố',
  mfaLoginInstructions: 'Vui lòng nhập mã số được tạo trên thiết bị di động của bạn.',
  mfaSubmitLabel: 'Đăng nhập',
  mfaCodeErrorHint: 'Chỉ sử dụng %d số',
  forgotPasswordTitle: 'Đặt lại mật khẩu của bạn',
  signUpTitle: 'Đăng ký',
  showPassword: 'Hiển thị mật khẩu',
  signUpTerms:
    'Bằng cách đăng ký, bạn đồng ý với các điều khoản dịch vụ và chính sách bảo mật của chúng tôi.'
};
