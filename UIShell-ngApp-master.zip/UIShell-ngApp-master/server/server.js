const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
const app = express();
global.fetch = require('node-fetch');
const AWS = require('aws-sdk');
const AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const cors = require('cors');
const api = require('./api.router');
const config = require('./config.cognito.json');

// const poolData = {
//   UserPoolID: config.cognito.user_pool_ID,
//   ClientID: config.cognito.client_ID
// };
// const userPool = new AmazonCognitoIdentiy.CognitoUserPool(poolData);

api.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.all("/*", function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
  next();
});
// Angular DIST output folder
app.use(express.static(path.join(__dirname, 'dist')));

//sign up data
app.post('/testReq', bodyParser.json(), (req, res) => {
  res.json(req.body)
});

//login
app.post('/login', bodyParser.json(), (req,res) => {
  const poolData = {
    UserPoolId: 'us-east-2_lcN77dUbd', //config.cognito.user_pool_ID,
    ClientId: 'ki38le47mmi58euv9029cdm6s' //config.cognito.client_ID
  };
  var authenticationData = {
    Username : req.body.name,
    Password : req.body.pwd,
  };
  var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
  var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
  var userData = {
      Username : req.body.name,
      Pool : userPool
  };
  var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
  cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: function (result) {
          var accessToken = result.getAccessToken().getJwtToken();
          console.log('accessToken'+ accessToken)
          /* Use the idToken for Logins Map when Federating User Pools with identity pools or when passing through an Authorization Header to an API Gateway Authorizer*/
          var idToken = result.idToken.jwtToken;
          console.log('id Token' + idToken);
          res.json(result);
      },

      onFailure: function(err) {
          console.log(err);
          res.json(err);
      },

  });
})

app.post('/signup', bodyParser.json(), (req, res) => {
  const poolData = {
    UserPoolId: 'us-east-2_lcN77dUbd', //config.cognito.user_pool_ID,
    ClientId: 'ki38le47mmi58euv9029cdm6s' //config.cognito.client_ID
  };
  var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
  var attributeList = [];
  var dataEmail = {
    Name: 'email',
    Value: req.body.email,
  };
  var dataName = {
    Name: 'name',
    Value: req.body.email
  };
  var dataPhoneNumber = {
    Name: 'phone_number',
    Value: '+919994485954'
  };
  var username = req.body.email;// 'saranraj.chinnapaiyan@fisglobal.com';
  var password = req.body.pwd; //'saran@123';
  var attributeName = new AmazonCognitoIdentity.CognitoUserAttribute(dataName);
  var attributeEmail = new AmazonCognitoIdentity.CognitoUserAttribute(dataEmail);
  var attributePhoneNumber = new AmazonCognitoIdentity.CognitoUserAttribute(dataPhoneNumber);

  attributeList.push(attributeEmail);
  attributeList.push(attributePhoneNumber);
  attributeList.push(attributeName);
  var cognitoUser;
  userPool.signUp(username, password, attributeList, null, function (err, result) {
    if (err) {
      console.log(err);
      res.json(err);
    } else {
      cognitoUser = result.user;
      console.log('user name is ' + cognitoUser.getUsername());
      // send the result 
      res.json(result);
    }
  })
  var currentUserDetails = userPool.getCurrentUser();
  console.log(currentUserDetails);
});

app.post('/postData', bodyParser.json(), (req, res) => {
  res.json(req.body)
});

// Error handling
const sendError = (err, res) => {
  response.status = 501;
  response.message = typeof err == 'object' ? err.message : err;
  res.status(501).json(response);
};

// Response handling
let response = {
  status: 200,
  data: [],
  message: null
};


const port = process.env.PORT || '3000';
app.set('port', port);

const server = http.createServer(app);

server.listen(port, () => console.log(`Running on localhost:${port}`));
// AWS starts
// const EC2 = new AWS.EC2();
// AWS.config.credentials =  new AWS.EC2MetadataCredentials();
// AWS.config.update({ region: 'us-west-2' });
// AWS.config.credentials.httpOptions = { timeout: 5000 };
// AWS.config.maxRetires = 10;
// AWS.retryDelayOptions = { base:200 }

  // AWS_ACCESS_KEY_ID
  // AWS_SECRET_ACCESS_KEY
  // AWS_REGION

  // // AWS Service Object
  // AWS.S3
  // AWS.EC2
  // AWS.DynamoDB
  // AWS.SQS
  // AWS.SNS

// ends
